-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Хост: 127.0.0.1:3306
-- Время создания: Июл 06 2020 г., 16:59
-- Версия сервера: 10.3.22-MariaDB
-- Версия PHP: 7.2.29

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- База данных: `hometask6`
--

-- --------------------------------------------------------

--
-- Структура таблицы `feedback`
--

CREATE TABLE `feedback` (
  `id` int(11) NOT NULL,
  `name` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `text` text COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Дамп данных таблицы `feedback`
--

INSERT INTO `feedback` (`id`, `name`, `text`) VALUES
(1, 'Илья', 'Отличный сервис. '),
(2, 'Вася', 'Все понравилось. Будем работать вместе и дальше.'),
(3, 'Маша', 'Все очень понравилось. Желаю удачи в вашем не легком деле.'),
(4, 'Дима', 'Ни на что не рассчитывал, но в итоге все получилось очень здорово');

-- --------------------------------------------------------

--
-- Структура таблицы `gallery`
--

CREATE TABLE `gallery` (
  `id` int(11) NOT NULL,
  `title` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `path` varchar(30) COLLATE utf8mb4_unicode_ci NOT NULL,
  `discript` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `bigdis` text COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Дамп данных таблицы `gallery`
--

INSERT INTO `gallery` (`id`, `title`, `path`, `discript`, `bigdis`) VALUES
(1, 'Xiaomi Redmi Note 8 ', '../images/', 'Смартфон Xiaomi RedMi Note 8 4/64GB Blue (Синий) EU был выпущен в 2019 году. Это недорогой аппарат, который получил качественную 48 Мп камеру, систему ИИ, мощный процессор и безрамочный экран. Он предназначен для европейского рынка, что можно понять по значку EU в названии.', 'Смартфон Xiaomi RedMi Note 8 4/64GB Blue (Синий) EU был выпущен в 2019 году. Это недорогой аппарат, который получил качественную 48 Мп камеру, систему ИИ, мощный процессор и безрамочный экран. Он предназначен для европейского рынка, что можно понять по значку EU в названии.\r\n\r\nКонструкция выполнена из крепкого пластика. Все грани немного скруглены, из-за чего пользоваться телефоном удобно. Такой подход разработчики всегда используют в производстве девайсов, из-за чего внешне они похожи. Вся лицевая часть занята большим экраном, вокруг которого нет рамок. Элементы управления здесь тоже отсутствуют. Только в самом верху есть фронтальная камера, встроенная в каплевидный вырез.'),
(2, 'Xiaomi Mi Band 4 Red', '../images/', 'Современный девайс с комплектацией, возможностями и функциями флагмана, который позволит сделать жизнь проще, а тренировки эффективнее - все это Xiaomi Mi Band 4 Vinous.', 'Современный девайс с комплектацией, возможностями и функциями флагмана, который позволит сделать жизнь проще, а тренировки эффективнее - все это Xiaomi Mi Band 4 Vinous.\r\n\r\nМодель оборудована обновленным AMOLED-дисплеем с диагональю 0.95 дюймов и разрешением 120х240. Он поддерживает широкую палитру цветов и способен обеспечивать максимальную информативность. Уведомления, текст, изображения и другая важная информация всегда будет видна с первого взгляда. При этом, оформление циферблата можно изменить в любой момент.\r\n\r\n'),
(3, 'Xiaomi AirDots 2S', '../images/', 'Mi AirDots Pro 2s – улучшеннаю версию беспроводных наушников Mi AirDots Pro 2, которые были представлены в прошлом году. Он имеет тот же дизайн и поставляется с Bluetooth 5.0, аудиокодеком LDHC Hi-Res, интеллектуальным голосовым управлением, двойными микрофонами для подавления шума окружающей среды (ENC), драйверами 14,2 мм.', 'Беспроводные наушники способны автоматически подключается к телефону под управлением MIUI, когда вы открываете корпус и поднимаете наушники. Двойной чип Bluetooth улучшен, чтобы уменьшить задержку и помехи между гарнитурами. Новая версия Bluetooth должна обеспечить более стабильное соединение.\r\n\r\nЕще одним дополнением является новый корпус с поддержкой беспроводной зарядки Qi. Это также обеспечивает до 24 часов автономной работы по сравнению с 14 часами в предшественнике. Помимо этого, время автономной работы увеличилось до 5 часов по сравнению с 4 часами.');

-- --------------------------------------------------------

--
-- Структура таблицы `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `login` varchar(15) COLLATE utf8mb4_unicode_ci NOT NULL,
  `pass` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `role` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Дамп данных таблицы `users`
--

INSERT INTO `users` (`id`, `login`, `pass`, `role`) VALUES
(1, 'admin', '12345', 1),
(2, 'user', '123', 0);

--
-- Индексы сохранённых таблиц
--

--
-- Индексы таблицы `feedback`
--
ALTER TABLE `feedback`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `gallery`
--
ALTER TABLE `gallery`
  ADD PRIMARY KEY (`id`);

--
-- Индексы таблицы `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT для сохранённых таблиц
--

--
-- AUTO_INCREMENT для таблицы `feedback`
--
ALTER TABLE `feedback`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT для таблицы `gallery`
--
ALTER TABLE `gallery`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT для таблицы `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
